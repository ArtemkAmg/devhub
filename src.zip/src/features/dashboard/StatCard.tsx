import type { DashboardStat } from "@/types/dashboard";

interface Props {
  stat: DashboardStat;
}

const StatCard = ({ stat }: Props) => {
  const Icon = stat.icon;

  return (
    <div className="rounded-2xl bg-white p-6 shadow-sm border border-zinc-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-zinc-500">
            {stat.title}
          </p>

          <h2 className="mt-2 text-3xl font-bold">
            {stat.value}
          </h2>
        </div>

        <div className="rounded-xl bg-zinc-100 p-3">
          <Icon className="h-6 w-6 text-black" />
        </div>
      </div>
    </div>
  );
};

export default StatCard;