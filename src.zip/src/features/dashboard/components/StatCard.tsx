import type { DashboardStat } from "@/types/dashboard";

interface Props {
  stat: DashboardStat;
}

export default function StatCard({ stat }: Props) {
  const Icon = stat.icon;

  return (
    <article className="stat-card">
      <div className="stat-card__top">
        <span>{stat.title}</span>

        <div className="stat-card__icon">
          <Icon size={20} />
        </div>
      </div>

      <h2>{stat.value}</h2>

      <p>
        <span>↗ 12%</span> from last month
      </p>
    </article>
  );
}