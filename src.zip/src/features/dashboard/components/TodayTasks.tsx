import { recentTasks } from "../data/dashboard";

export default function TodayTasks() {
  const completedTasks = recentTasks.filter((task) => task.completed).length;

  return (
    <section className="dashboard-card">
      <div className="card-heading">
        <div>
          <p>FOCUS FOR TODAY</p>
          <h2>Today's tasks</h2>
        </div>

        <span className="task-count">
          {completedTasks}/{recentTasks.length} done
        </span>
      </div>

      <div className="task-list">
        {recentTasks.map((task) => (
          <label key={task.id} className="task-row">
            <input type="checkbox" checked={task.completed} readOnly />

            <span
              className={`task-title ${
                task.completed ? "task-title--done" : ""
              }`}
            >
              {task.title}
            </span>
          </label>
        ))}
      </div>
    </section>
  );
}