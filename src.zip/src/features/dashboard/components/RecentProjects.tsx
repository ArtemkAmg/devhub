import { recentProjects } from "../data/dashboard";

export default function RecentProjects() {
  return (
    <section className="dashboard-card">
      <div className="card-heading">
        <div>
          <p>IN PROGRESS</p>
          <h2>Recent projects</h2>
        </div>

        <button type="button">View all</button>
      </div>

      <div className="project-list">
        {recentProjects.map((project) => (
          <div key={project.id} className="project-row">
            <div className={`project-dot project-dot--${project.id}`} />

            <div>
              <strong>{project.name}</strong>
              <span>Updated recently</span>
            </div>

            <button
              type="button"
              className="more-button"
              aria-label={`Open ${project.name}`}
            >
              •••
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}