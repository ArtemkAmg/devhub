import {
  FiBookOpen,
  FiCheckSquare,
  FiFolder,
  FiStar,
} from "react-icons/fi";

export const stats = [
  {
    title: "Projects",
    value: 12,
    icon: FiFolder,
  },
  {
    title: "Tasks",
    value: 37,
    icon: FiCheckSquare,
  },
  {
    title: "Notes",
    value: 24,
    icon: FiBookOpen,
  },
  {
    title: "Completed",
    value: "84%",
    icon: FiStar,
  },
];

export const recentProjects = [
  {
    id: 1,
    name: "DevHub",
  },
  {
    id: 2,
    name: "Portfolio",
  },
  {
    id: 3,
    name: "CRM Dashboard",
  },
];

export const recentTasks = [
  {
    id: 1,
    title: "Finish dashboard interface",
    completed: true,
  },
  {
    id: 2,
    title: "Create projects page",
    completed: false,
  },
  {
    id: 3,
    title: "Add responsive mobile menu",
    completed: false,
  },
];