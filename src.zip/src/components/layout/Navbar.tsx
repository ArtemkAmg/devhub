import { FiBell, FiSearch } from "react-icons/fi";

export default function Navbar() {
  return (
    <header className="navbar">
      <label className="search-box">
        <FiSearch size={18} className="search-icon" />

        <input
          type="text"
          placeholder="Search projects, tasks..."
          className="search-input"
        />
      </label>

      <div className="navbar-actions">
        <button className="icon-button" aria-label="Notifications">
          <FiBell size={20} />
        </button>

        <div className="profile-preview">
          <div className="avatar">A</div>

          <div>
            <h2>Artem</h2>
            <p>Developer</p>
          </div>
        </div>
      </div>
    </header>
  );
}