import { NavLink } from "react-router-dom";
import {
  FiBookOpen,
  FiCheckSquare,
  FiFolder,
  FiHome,
  FiSettings,
  FiUser,
} from "react-icons/fi";

const links = [
  { title: "Dashboard", path: "/", icon: FiHome },
  { title: "Projects", path: "/projects", icon: FiFolder },
  { title: "Tasks", path: "/tasks", icon: FiCheckSquare },
  { title: "Notes", path: "/notes", icon: FiBookOpen },
  { title: "Profile", path: "/profile", icon: FiUser },
  { title: "Settings", path: "/settings", icon: FiSettings },
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">D</div>

        <div>
          <h1>DevHub</h1>
          <p>Personal workspace</p>
        </div>
      </div>

      <nav className="sidebar-nav">
        {links.map((link) => {
          const Icon = link.icon;

          return (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `nav-link ${isActive ? "nav-link--active" : ""}`
              }
            >
              <Icon size={19} />
              <span>{link.title}</span>
            </NavLink>
          );
        })}
      </nav>

      <div className="sidebar-profile">
        <div className="profile-preview">
          <div className="avatar">A</div>

          <div>
            <h2>Artem</h2>
            <p>Frontend Developer</p>
          </div>
        </div>
      </div>
    </aside>
  );
}