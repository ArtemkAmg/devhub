import type { IconType } from "react-icons";

export interface DashboardStat {
  title: string;
  value: number | string;
  icon: IconType;
}

export interface RecentProject {
  id: number;
  name: string;
  color: string;
}

export interface RecentTask {
  id: number;
  title: string;
  completed: boolean;
}