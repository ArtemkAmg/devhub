import { create } from "zustand";
import { persist } from "zustand/middleware";

export type TaskStatus = "todo" | "in-progress" | "completed";
export type ProjectStatus = "active" | "completed";

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: "low" | "medium" | "high";
  dueDate?: string;
  createdAt: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: ProjectStatus;
  createdAt: string;
  tasks: Task[];
}

interface AppState {
  projects: Project[];

  addProject: (project: Omit<Project, "id" | "createdAt">) => void;

  updateProject: (id: string, data: Partial<Project>) => void;

  deleteProject: (id: string) => void;

  addTask: (
    projectId: string,
    task: Omit<Task, "id" | "createdAt">
  ) => void;

  updateTask: (
    projectId: string,
    taskId: string,
    data: Partial<Task>
  ) => void;

  deleteTask: (
    projectId: string,
    taskId: string
  ) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      projects: [],

      addProject: (project) =>
        set((state) => ({
          projects: [
            ...state.projects,
            {
              ...project,
              id: crypto.randomUUID(),
              createdAt: new Date().toISOString(),
            },
          ],
        })),

      updateProject: (id, data) =>
        set((state) => ({
          projects: state.projects.map((project) =>
            project.id === id
              ? {
                  ...project,
                  ...data,
                }
              : project
          ),
        })),

      deleteProject: (id) =>
        set((state) => ({
          projects: state.projects.filter(
            (project) => project.id !== id
          ),
        })),

      addTask: (projectId, task) =>
        set((state) => ({
          projects: state.projects.map((project) => {
            if (project.id !== projectId) return project;

            return {
              ...project,
              tasks: [
                ...project.tasks,
                {
                  ...task,
                  id: crypto.randomUUID(),
                  createdAt: new Date().toISOString(),
                },
              ],
            };
          }),
        })),

      updateTask: (projectId, taskId, data) =>
        set((state) => ({
          projects: state.projects.map((project) => {
            if (project.id !== projectId) return project;

            return {
              ...project,
              tasks: project.tasks.map((task) =>
                task.id === taskId
                  ? {
                      ...task,
                      ...data,
                    }
                  : task
              ),
            };
          }),
        })),

      deleteTask: (projectId, taskId) =>
        set((state) => ({
          projects: state.projects.map((project) => {
            if (project.id !== projectId) return project;

            return {
              ...project,
              tasks: project.tasks.filter(
                (task) => task.id !== taskId
              ),
            };
          }),
        })),
    }),
    {
      name: "devhub-storage",
    }
  )
);