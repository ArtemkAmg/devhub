import {
  FiClock,
  FiEdit3,
  FiFileText,
  FiMoreHorizontal,
  FiPlus,
  FiSearch,
  FiStar,
} from "react-icons/fi";

const notes = [
  {
    id: 1,
    title: "DevHub — next improvements",
    text: "Add project filters, a task calendar and a simple dark mode switch.",
    date: "Edited today",
    color: "purple",
    favorite: true,
  },
  {
    id: 2,
    title: "Portfolio content ideas",
    text: "Focus on real results, development process and a strong contact section.",
    date: "Edited yesterday",
    color: "orange",
    favorite: true,
  },
  {
    id: 3,
    title: "CRM dashboard research",
    text: "Ideas for customer overview, sales statistics and quick actions.",
    date: "Edited Jul 8",
    color: "blue",
    favorite: false,
  },
  {
    id: 4,
    title: "Weekly goals",
    text: "Finish the visual design, improve mobile layout and plan the next sprint.",
    date: "Edited Jul 6",
    color: "green",
    favorite: false,
  },
  {
    id: 5,
    title: "Useful resources",
    text: "Typography inspiration, interface references and animation examples.",
    date: "Edited Jul 2",
    color: "pink",
    favorite: false,
  },
  {
    id: 6,
    title: "Client meeting notes",
    text: "Discuss the project scope, visual direction and launch timeline.",
    date: "Edited Jun 29",
    color: "yellow",
    favorite: false,
  },
];

export default function NotesPage() {
  return (
    <div className="notes-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">PERSONAL KNOWLEDGE BASE</p>
          <h1>Notes</h1>
          <p>Capture thoughts, ideas and important details in one place.</p>
        </div>

        <button className="primary-button" type="button">
          <FiPlus size={17} />
          New note
        </button>
      </div>

      <div className="notes-toolbar">
        <label className="notes-search">
          <FiSearch size={17} />

          <input type="text" placeholder="Search notes..." />
        </label>

        <div className="notes-filters">
          <button className="note-filter note-filter--active" type="button">
            All notes
          </button>

          <button className="note-filter" type="button">
            Favorites
          </button>
        </div>
      </div>

      <div className="notes-layout">
        <aside className="notes-sidebar">
          <p>COLLECTIONS</p>

          <button className="notes-sidebar-link notes-sidebar-link--active">
            <FiFileText size={16} />
            All notes
            <span>6</span>
          </button>

          <button className="notes-sidebar-link">
            <FiStar size={16} />
            Favorites
            <span>2</span>
          </button>

          <div className="notes-sidebar-divider" />

          <p>TAGS</p>

          <button className="note-tag">
            <i className="tag-dot tag-dot--purple" />
            Design
          </button>

          <button className="note-tag">
            <i className="tag-dot tag-dot--orange" />
            Ideas
          </button>

          <button className="note-tag">
            <i className="tag-dot tag-dot--blue" />
            Development
          </button>
        </aside>

        <section className="notes-grid">
          {notes.map((note) => (
            <article className="note-card" key={note.id}>
              <div className="note-card__top">
                <div className={`note-color note-color--${note.color}`} />

                <button
                  type="button"
                  className="more-button"
                  aria-label={`More options for ${note.title}`}
                >
                  <FiMoreHorizontal size={19} />
                </button>
              </div>

              <h2>{note.title}</h2>
              <p>{note.text}</p>

              <div className="note-card__footer">
                <span>
                  <FiClock size={13} />
                  {note.date}
                </span>

                {note.favorite && (
                  <FiStar className="note-favorite" size={16} fill="currentColor" />
                )}
              </div>
            </article>
          ))}

          <button className="note-create-card" type="button">
            <span>
              <FiEdit3 size={21} />
            </span>
            <strong>Create a new note</strong>
            <small>Write down a thought before it disappears.</small>
          </button>
        </section>
      </div>
    </div>
  );
}