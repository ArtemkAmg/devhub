import {
  FiBell,
  FiChevronRight,
  FiGlobe,
  FiLock,
  FiMoon,
  FiSave,
  FiShield,
  FiSliders,
} from "react-icons/fi";

export default function SettingsPage() {
  return (
    <div className="settings-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">WORKSPACE PREFERENCES</p>
          <h1>Settings</h1>
          <p>Adjust the workspace so it feels comfortable for you.</p>
        </div>

        <button className="primary-button" type="button">
          <FiSave size={16} />
          Save changes
        </button>
      </div>

      <div className="settings-layout">
        <aside className="settings-menu">
          <button className="settings-menu__item settings-menu__item--active">
            <FiSliders size={17} />
            General
          </button>

          <button className="settings-menu__item">
            <FiBell size={17} />
            Notifications
          </button>

          <button className="settings-menu__item">
            <FiLock size={17} />
            Security
          </button>

          <button className="settings-menu__item">
            <FiGlobe size={17} />
            Language & region
          </button>
        </aside>

        <div className="settings-content">
          <section className="settings-card">
            <div className="settings-card__heading">
              <div>
                <p>APPEARANCE</p>
                <h2>Theme preferences</h2>
              </div>

              <FiMoon size={20} />
            </div>

            <div className="theme-options">
              <button className="theme-option theme-option--active" type="button">
                <span className="theme-preview theme-preview--light">
                  <i />
                  <b />
                  <em />
                </span>

                <strong>Light</strong>
                <small>Clean and bright</small>
              </button>

              <button className="theme-option" type="button">
                <span className="theme-preview theme-preview--dark">
                  <i />
                  <b />
                  <em />
                </span>

                <strong>Dark</strong>
                <small>Easy on the eyes</small>
              </button>

              <button className="theme-option" type="button">
                <span className="theme-preview theme-preview--system">
                  <i />
                  <b />
                  <em />
                </span>

                <strong>System</strong>
                <small>Match device theme</small>
              </button>
            </div>
          </section>

          <section className="settings-card">
            <div className="settings-card__heading">
              <div>
                <p>NOTIFICATIONS</p>
                <h2>Stay in the loop</h2>
              </div>

              <FiBell size={20} />
            </div>

            <div className="setting-list">
              <div className="setting-row">
                <div>
                  <strong>Task reminders</strong>
                  <p>Get notified when a task is close to its due date.</p>
                </div>

                <label className="switch">
                  <input type="checkbox" checked readOnly />
                  <span />
                </label>
              </div>

              <div className="setting-row">
                <div>
                  <strong>Weekly summary</strong>
                  <p>Receive a short overview of your workspace every week.</p>
                </div>

                <label className="switch">
                  <input type="checkbox" checked readOnly />
                  <span />
                </label>
              </div>

              <div className="setting-row">
                <div>
                  <strong>Project updates</strong>
                  <p>Receive updates when a project activity changes.</p>
                </div>

                <label className="switch">
                  <input type="checkbox" readOnly />
                  <span />
                </label>
              </div>
            </div>
          </section>

          <section className="settings-card">
            <div className="settings-card__heading">
              <div>
                <p>ACCOUNT</p>
                <h2>Security & privacy</h2>
              </div>

              <FiShield size={20} />
            </div>

            <div className="account-settings">
              <button type="button">
                <span>
                  <strong>Change password</strong>
                  <small>Choose a new secure password for your account.</small>
                </span>

                <FiChevronRight size={18} />
              </button>

              <button type="button">
                <span>
                  <strong>Two-factor authentication</strong>
                  <small>Add another layer of protection to your account.</small>
                </span>

                <span className="settings-badge">Recommended</span>
                <FiChevronRight size={18} />
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}