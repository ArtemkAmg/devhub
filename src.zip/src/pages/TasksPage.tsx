import {
  FiCalendar,
  FiCheckCircle,
  FiChevronDown,
  FiClock,
  FiFilter,
  FiPlus,
} from "react-icons/fi";

const tasks = [
  {
    id: 1,
    title: "Finish dashboard interface",
    project: "DevHub",
    date: "Today, 16:00",
    priority: "High",
    completed: true,
  },
  {
    id: 2,
    title: "Create projects page",
    project: "DevHub",
    date: "Today, 18:00",
    priority: "High",
    completed: false,
  },
  {
    id: 3,
    title: "Prepare portfolio case study",
    project: "Portfolio",
    date: "Tomorrow",
    priority: "Medium",
    completed: false,
  },
  {
    id: 4,
    title: "Review CRM dashboard layout",
    project: "CRM Dashboard",
    date: "Jul 15",
    priority: "Low",
    completed: false,
  },
  {
    id: 5,
    title: "Add mobile navigation",
    project: "TaskFlow",
    date: "Jul 17",
    priority: "Medium",
    completed: false,
  },
];

export default function TasksPage() {
  const completedCount = tasks.filter((task) => task.completed).length;

  return (
    <div className="tasks-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">PERSONAL PLANNER</p>
          <h1>Tasks</h1>
          <p>Keep your priorities clear and move work forward.</p>
        </div>

        <button className="primary-button" type="button">
          <FiPlus size={17} />
          Add task
        </button>
      </div>

      <div className="tasks-summary">
        <div className="tasks-summary__icon">
          <FiCheckCircle size={24} />
        </div>

        <div>
          <strong>
            {completedCount} of {tasks.length} tasks completed
          </strong>
          <p>Small steps every day create meaningful progress.</p>
        </div>

        <div className="tasks-summary__progress">
          <span style={{ width: `${(completedCount / tasks.length) * 100}%` }} />
        </div>
      </div>

      <div className="tasks-toolbar">
        <div className="task-filter-list">
          <button className="task-filter task-filter--active" type="button">
            All <span>{tasks.length}</span>
          </button>

          <button className="task-filter" type="button">
            Today <span>2</span>
          </button>

          <button className="task-filter" type="button">
            Upcoming <span>3</span>
          </button>
        </div>

        <div className="task-toolbar-actions">
          <button className="toolbar-button" type="button">
            <FiFilter size={15} />
            Filter
          </button>

          <button className="toolbar-button" type="button">
            <FiCalendar size={15} />
            This week
            <FiChevronDown size={14} />
          </button>
        </div>
      </div>

      <section className="tasks-board">
        <div className="task-board-heading">
          <span>Task</span>
          <span>Project</span>
          <span>Due date</span>
          <span>Priority</span>
        </div>

        <div className="task-board-list">
          {tasks.map((task) => (
            <div className="task-board-row" key={task.id}>
              <div className="task-board-title">
                <input type="checkbox" checked={task.completed} readOnly />

                <span className={task.completed ? "board-task--done" : ""}>
                  {task.title}
                </span>
              </div>

              <span className="project-pill">{task.project}</span>

              <span className="task-date">
                <FiClock size={14} />
                {task.date}
              </span>

              <span
                className={`priority priority--${task.priority.toLowerCase()}`}
              >
                {task.priority}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}