import StatCard from "@/features/dashboard/components/StatCard";
import RecentProjects from "@/features/dashboard/components/RecentProjects";
import TodayTasks from "@/features/dashboard/components/TodayTasks";
import { stats } from "@/features/dashboard/data/dashboard";

export default function DashboardPage() {
  return (
    <div className="dashboard">
      <div className="page-heading">
        <div>
          <p className="eyebrow">Saturday, July 12</p>
          <h1>
            Good morning, Artem <span aria-hidden="true">👋</span>
          </h1>
          <p>Here is a clear view of what is moving forward today.</p>
        </div>

        <button className="primary-button">+ New project</button>
      </div>

      <div className="stats-grid">
        {stats.map((stat) => (
          <StatCard key={stat.title} stat={stat} />
        ))}
      </div>

      <div className="dashboard-grid">
        <RecentProjects />
        <TodayTasks />
      </div>
    </div>
  );
}