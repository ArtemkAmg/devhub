import {
  FiArrowUpRight,
  FiClock,
  FiFolder,
  FiMoreHorizontal,
  FiPlus,
} from "react-icons/fi";

const projects = [
  {
    id: 1,
    title: "DevHub",
    description: "Personal productivity workspace for developers.",
    progress: 78,
    color: "purple",
    tasks: "18 / 24 tasks",
    updated: "Updated 2 hours ago",
  },
  {
    id: 2,
    title: "Portfolio",
    description: "Personal website with selected work and contacts.",
    progress: 45,
    color: "orange",
    tasks: "9 / 20 tasks",
    updated: "Updated yesterday",
  },
  {
    id: 3,
    title: "CRM Dashboard",
    description: "A clean dashboard for managing customers and sales.",
    progress: 26,
    color: "green",
    tasks: "5 / 19 tasks",
    updated: "Updated 3 days ago",
  },
  {
    id: 4,
    title: "TaskFlow",
    description: "Simple task-management experience for small teams.",
    progress: 92,
    color: "blue",
    tasks: "23 / 25 tasks",
    updated: "Updated 5 days ago",
  },
];

export default function ProjectsPage() {
  return (
    <div className="projects-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">YOUR WORKSPACE</p>
          <h1>Projects</h1>
          <p>Keep an eye on every project currently in progress.</p>
        </div>

        <button className="primary-button" type="button">
          <FiPlus size={17} />
          New project
        </button>
      </div>

      <div className="projects-toolbar">
        <div className="project-tabs">
          <button type="button" className="project-tab project-tab--active">
            All projects <span>4</span>
          </button>

          <button type="button" className="project-tab">
            Active <span>3</span>
          </button>

          <button type="button" className="project-tab">
            Completed <span>1</span>
          </button>
        </div>

        <button type="button" className="sort-button">
          Recently updated
        </button>
      </div>

      <div className="projects-grid">
        {projects.map((project) => (
          <article className="project-card" key={project.id}>
            <div className="project-card__top">
              <div className={`project-card__icon icon--${project.color}`}>
                <FiFolder size={21} />
              </div>

              <button
                type="button"
                className="more-button"
                aria-label={`More options for ${project.title}`}
              >
                <FiMoreHorizontal size={20} />
              </button>
            </div>

            <h2>{project.title}</h2>
            <p className="project-card__description">{project.description}</p>

            <div className="project-card__progress">
              <div className="progress-label">
                <span>Progress</span>
                <strong>{project.progress}%</strong>
              </div>

              <div className="progress-bar">
                <div
                  className={`progress-bar__value progress--${project.color}`}
                  style={{ width: `${project.progress}%` }}
                />
              </div>
            </div>

            <div className="project-card__footer">
              <span>
                <FiClock size={14} />
                {project.updated}
              </span>

              <span>{project.tasks}</span>
            </div>

            <button className="open-project-button" type="button">
              Open project
              <FiArrowUpRight size={16} />
            </button>
          </article>
        ))}
      </div>
    </div>
  );
}