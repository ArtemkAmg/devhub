import {
  FiBriefcase,
  FiCamera,
  FiCheck,
  FiCode,
  FiEdit3,
  FiGithub,
  FiGlobe,
  FiMail,
  FiMapPin,
} from "react-icons/fi";

const skills = ["React", "TypeScript", "JavaScript", "HTML", "CSS", "Figma"];

export default function ProfilePage() {
  return (
    <div className="profile-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">PERSONAL PROFILE</p>
          <h1>Profile</h1>
          <p>Manage your public information and developer identity.</p>
        </div>

        <button className="primary-button" type="button">
          <FiEdit3 size={16} />
          Edit profile
        </button>
      </div>

      <section className="profile-hero">
        <div className="profile-cover" />

        <div className="profile-hero__content">
          <div className="profile-avatar">
            A
            <button type="button" aria-label="Change profile photo">
              <FiCamera size={15} />
            </button>
          </div>

          <div className="profile-intro">
            <div>
              <h2>Artem</h2>
              <p>Frontend Developer</p>
            </div>

            <span className="profile-status">
              <i />
              Available for work
            </span>
          </div>

          <div className="profile-details">
            <span>
              <FiMapPin size={15} />
              Kyiv, Ukraine
            </span>

            <span>
              <FiBriefcase size={15} />
              Freelance developer
            </span>

            <span>
              <FiMail size={15} />
              artem@example.com
            </span>
          </div>
        </div>
      </section>

      <div className="profile-grid">
        <section className="profile-card profile-about">
          <div className="profile-card__heading">
            <div>
              <p>ABOUT ME</p>
              <h2>Short introduction</h2>
            </div>
          </div>

          <p>
            I am a frontend developer who enjoys turning ideas into clean,
            responsive and thoughtful digital experiences. I focus on details,
            clear interfaces and useful products.
          </p>

          <div className="profile-links">
            <a href="#" aria-label="GitHub profile">
              <FiGithub size={18} />
              GitHub
            </a>

            <a href="#" aria-label="Personal website">
              <FiGlobe size={18} />
              Website
            </a>
          </div>
        </section>

        <section className="profile-card">
          <div className="profile-card__heading">
            <div>
              <p>EXPERTISE</p>
              <h2>Skills & tools</h2>
            </div>

            <FiCode className="profile-heading-icon" size={20} />
          </div>

          <div className="skills-list">
            {skills.map((skill) => (
              <span key={skill}>
                <FiCheck size={13} />
                {skill}
              </span>
            ))}
          </div>
        </section>

        <section className="profile-card profile-activity">
          <div className="profile-card__heading">
            <div>
              <p>ACTIVITY</p>
              <h2>Workspace summary</h2>
            </div>
          </div>

          <div className="profile-stats">
            <div>
              <strong>12</strong>
              <span>Projects</span>
            </div>

            <div>
              <strong>37</strong>
              <span>Tasks</span>
            </div>

            <div>
              <strong>24</strong>
              <span>Notes</span>
            </div>
          </div>
        </section>
      </div>

      <section className="profile-card profile-form-card">
        <div className="profile-card__heading">
          <div>
            <p>PERSONAL INFORMATION</p>
            <h2>Basic details</h2>
          </div>
        </div>

        <div className="profile-form">
          <label>
            Full name
            <input defaultValue="Artem" />
          </label>

          <label>
            Professional role
            <input defaultValue="Frontend Developer" />
          </label>

          <label>
            Email address
            <input defaultValue="artem@example.com" type="email" />
          </label>

          <label>
            Location
            <input defaultValue="Kyiv, Ukraine" />
          </label>
        </div>
      </section>
    </div>
  );
}